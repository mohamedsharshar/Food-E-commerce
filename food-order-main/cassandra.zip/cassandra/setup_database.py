from cassandra.cluster import Cluster

cluster = Cluster(['127.0.0.1'])  
session = cluster.connect()

session.execute("""
CREATE KEYSPACE IF NOT EXISTS project WITH REPLICATION = {
 'class': 'SimpleStrategy',
 'replication_factor': 1
};
""")

session.set_keyspace('project')

session.execute("""
CREATE TABLE IF NOT EXISTS customers (
    customer_id TEXT PRIMARY KEY,
    name TEXT,
    email TEXT,
    contact TEXT
);
""")

session.execute("""
CREATE TABLE IF NOT EXISTS orders (
    order_no TEXT PRIMARY KEY,
    customer_id TEXT,
    ticket_no TEXT,
    order_date TEXT,
    order_time TEXT,
    order_class TEXT
);
""")

session.execute("""
CREATE TABLE IF NOT EXISTS food_items (
    food_id TEXT PRIMARY KEY,
    food_name TEXT,
    price DOUBLE,
    category TEXT
);
""")

session.execute("""
CREATE TABLE IF NOT EXISTS payments (
    payment_id TEXT PRIMARY KEY,
    customer_id TEXT,
    amount DOUBLE,
    payment_date TEXT,
    cash_paid DOUBLE
);
""")

print("Database and tables are set up successfully!")
