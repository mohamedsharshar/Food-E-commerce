from cassandra.cluster import Cluster
import tkinter as tk
from tkinter import ttk, messagebox

cluster = Cluster(['127.0.0.1']) 
session = cluster.connect('project') 


def fetch_data(query, treeview):
    try:
        rows = session.execute(query)
        treeview.delete(*treeview.get_children())
        for row in rows:
            row_values = [str(value) for value in row]
            treeview.insert("", tk.END, values=row_values)
    except Exception as error:
        messagebox.showerror("Error", str(error))


def create_treeview(parent_frame, columns):
    tree_frame = ttk.Frame(parent_frame)
    tree_frame.grid(row=10, pady=70, column=0, columnspan=2, sticky="nsew")

    tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=10)
    tree.grid(row=0, column=0, sticky="nsew")

    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, anchor="center", stretch=True)

    tree_frame.grid_rowconfigure(0, weight=1)
    tree_frame.grid_columnconfigure(0, weight=1)

    total_width = 1000  
    for col in columns:
        tree.column(col, width=total_width // len(columns), anchor="center")

    return tree


def insert_customer():
    try:
        customer_id = cust_id_entry.get()
        name = cust_name_entry.get()
        email = cust_email_entry.get()
        contact = cust_contact_entry.get()
        
        if not customer_id or not name or not email or not contact:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        session.execute(
            """
            INSERT INTO customers (customer_id, name, email, contact)
            VALUES (%s, %s, %s, %s)
            """, (customer_id, name, email, contact)
        )
        messagebox.showinfo("Success", "Customer inserted successfully!")
        fetch_data("SELECT * FROM customers", customer_tree)
        clear_customer_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))


def insert_order():
    try:
        order_no = order_no_entry.get()
        customer_id = cust_id_order_entry.get()
        ticket_no = ticket_no_entry.get()
        order_date = order_date_entry.get()
        order_time = order_time_entry.get()
        order_class = order_class_entry.get()

        if not order_no or not customer_id or not ticket_no or not order_date or not order_time or not order_class:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        session.execute(
            """
            INSERT INTO orders (order_no, customer_id, order_class, order_date, order_time, ticket_no)
            VALUES (%s, %s, %s, %s, %s, %s)
            """, (order_no, customer_id, order_class, order_date, order_time, ticket_no)
        )
        messagebox.showinfo("Success", "Order inserted successfully!")
        fetch_data("SELECT * FROM orders", order_tree)
        clear_order_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))


def insert_food_item():
    try:
        food_id = food_id_entry.get()
        food_name = food_name_entry.get()
        price = price_entry.get()
        category = category_entry.get()

        if not food_id or not food_name or not price or not category:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        session.execute(
            """
            INSERT INTO food_items (food_id, food_name, price, category)
            VALUES (%s, %s, %s, %s)
            """, (food_id, food_name, float(price), category)
        )
        messagebox.showinfo("Success", "Food item inserted successfully!")
        fetch_data("SELECT * FROM food_items", food_tree)
        clear_food_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))


def insert_payment():
    try:
        payment_id = payment_id_entry.get()
        customer_id = payment_cust_id_entry.get()
        amount = payment_amount_entry.get()
        payment_date = payment_date_entry.get()
        cash_paid = payment_cash_paid_entry.get()

        if not payment_id or not customer_id or not amount or not payment_date or not cash_paid:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        session.execute(
            """
            INSERT INTO payments (payment_id, customer_id, amount, payment_date, cash_paid)
            VALUES (%s, %s, %s, %s, %s)
            """, (payment_id, customer_id, float(amount), payment_date, float(cash_paid))
        )
        messagebox.showinfo("Success", "Payment inserted successfully!")
        fetch_data("SELECT * FROM payments", payment_tree)
        clear_payment_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))


def delete_customer():
    try:
        selected_item = customer_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a customer to delete!")
            return

        customer_id = customer_tree.item(selected_item)["values"][0]  

        session.execute("DELETE FROM customers WHERE customer_id = %s", (customer_id,))
        messagebox.showinfo("Success", "Customer deleted successfully!")
        fetch_data("SELECT * FROM customers", customer_tree)
    except Exception as e:
        messagebox.showerror("Error", str(e))


def delete_order():
    try:
        selected_item = order_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select an order to delete!")
            return

        order_no = order_tree.item(selected_item)["values"][0]
        session.execute("DELETE FROM orders WHERE order_no = %s", (order_no,))
        messagebox.showinfo("Success", "Order deleted successfully!")
        fetch_data("SELECT * FROM orders", order_tree)
    except Exception as e:
        messagebox.showerror("Error", str(e))


def delete_food_item():
    try:
        selected_item = food_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a food item to delete!")
            return

        food_id = food_tree.item(selected_item)["values"][0]
        session.execute("DELETE FROM food_items WHERE food_id = %s", (food_id,))
        messagebox.showinfo("Success", "Food item deleted successfully!")
        fetch_data("SELECT * FROM food_items", food_tree)
    except Exception as e:
        messagebox.showerror("Error", str(e))


def delete_payment():
    try:
        selected_item = payment_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a payment to delete!")
            return

        payment_id = payment_tree.item(selected_item)["values"][0]
        session.execute("DELETE FROM payments WHERE payment_id = %s", (payment_id,))
        messagebox.showinfo("Success", "Payment deleted successfully!")
        fetch_data("SELECT * FROM payments", payment_tree)
    except Exception as e:
        messagebox.showerror("Error", str(e))

def update_customer():
    try:
        selected_item = customer_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a customer to update!")
            return

        customer_id = customer_tree.item(selected_item)["values"][0]  
        new_name = cust_name_entry.get()
        new_email = cust_email_entry.get()
        new_contact = cust_contact_entry.get()

        if not new_name or not new_email or not new_contact:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        session.execute(
            """
            UPDATE customers
            SET name = %s, email = %s, contact = %s
            WHERE customer_id = %s
            """, (new_name, new_email, new_contact, customer_id)
        )
        messagebox.showinfo("Success", "Customer updated successfully!")
        fetch_data("SELECT * FROM customers", customer_tree)
        clear_customer_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))


def update_order():
    try:
        selected_item = order_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select an order to update!")
            return

        order_no = order_tree.item(selected_item)["values"][0]
        new_customer_id = cust_id_order_entry.get()
        new_ticket_no = ticket_no_entry.get()
        new_order_date = order_date_entry.get()
        new_order_time = order_time_entry.get()
        new_order_class = order_class_entry.get()

        if not new_customer_id or not new_ticket_no or not new_order_date or not new_order_time or not new_order_class:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        session.execute(
            """
            UPDATE orders
            SET customer_id = %s, ticket_no = %s, order_date = %s, order_time = %s, order_class = %s
            WHERE order_no = %s
            """, (new_customer_id, new_ticket_no, new_order_date, new_order_time, new_order_class, order_no)
        )
        messagebox.showinfo("Success", "Order updated successfully!")
        fetch_data("SELECT * FROM orders", order_tree)
        clear_order_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))


def update_food_item():
    try:
        selected_item = food_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a food item to update!")
            return

        food_id = food_tree.item(selected_item)["values"][0]
        new_food_name = food_name_entry.get()
        new_price = price_entry.get()
        new_category = category_entry.get()

        if not new_food_name or not new_price or not new_category:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        session.execute(
            """
            UPDATE food_items
            SET food_name = %s, price = %s, category = %s
            WHERE food_id = %s
            """, (new_food_name, float(new_price), new_category, food_id)
        )
        messagebox.showinfo("Success", "Food item updated successfully!")
        fetch_data("SELECT * FROM food_items", food_tree)
        clear_food_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))


def update_payment():
    try:
        selected_item = payment_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a payment to update!")
            return

        payment_id = payment_tree.item(selected_item)["values"][0]
        new_customer_id = payment_cust_id_entry.get()
        new_amount = payment_amount_entry.get()
        new_payment_date = payment_date_entry.get()
        new_cash_paid = payment_cash_paid_entry.get()

        if not new_customer_id or not new_amount or not new_payment_date or not new_cash_paid:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        session.execute(
            """
            UPDATE payments
            SET customer_id = %s, amount = %s, payment_date = %s, cash_paid = %s
            WHERE payment_id = %s
            """, (new_customer_id, float(new_amount), new_payment_date, float(new_cash_paid), payment_id)
        )
        messagebox.showinfo("Success", "Payment updated successfully!")
        fetch_data("SELECT * FROM payments", payment_tree)
        clear_payment_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("Database Management System with Cassandra")
root.geometry("1000x700")
root.configure(bg='#eaeaea')
root.iconphoto(False, tk.PhotoImage(file="./database-management.png"))

notebook = ttk.Notebook(root)
notebook.pack(pady=10, expand=True, fill="both")

customer_tab = ttk.Frame(notebook)
notebook.add(customer_tab, text="Customers")

cust_id_label = ttk.Label(customer_tab, text="Customer ID:")
cust_id_label.grid(row=0, column=0, padx=10, pady=10)
cust_id_entry = ttk.Entry(customer_tab)
cust_id_entry.grid(row=0, column=1, padx=10, pady=10)

cust_name_label = ttk.Label(customer_tab, text="Customer Name:")
cust_name_label.grid(row=1, column=0, padx=10, pady=10)
cust_name_entry = ttk.Entry(customer_tab)
cust_name_entry.grid(row=1, column=1, padx=10, pady=10)

cust_email_label = ttk.Label(customer_tab, text="Customer Email:")
cust_email_label.grid(row=2, column=0, padx=10, pady=10)
cust_email_entry = ttk.Entry(customer_tab)
cust_email_entry.grid(row=2, column=1, padx=10, pady=10)

cust_contact_label = ttk.Label(customer_tab, text="Customer Contact No:")
cust_contact_label.grid(row=3, column=0, padx=10, pady=10)
cust_contact_entry = ttk.Entry(customer_tab)
cust_contact_entry.grid(row=3, column=1, padx=10, pady=10)

insert_customer_button = ttk.Button(customer_tab, text="Insert Customer", command=insert_customer)
insert_customer_button.grid(row=4, column=0, columnspan=2, pady=10)

columns = ("customer_id", "contact", "email", "name")
customer_tree = create_treeview(customer_tab, columns)
fetch_data("SELECT * FROM customers", customer_tree)

order_tab = ttk.Frame(notebook)
notebook.add(order_tab, text="Orders")

order_no_label = ttk.Label(order_tab, text="Order No:")
order_no_label.grid(row=0, column=0, padx=10, pady=10)
order_no_entry = ttk.Entry(order_tab)
order_no_entry.grid(row=0, column=1, padx=10, pady=10)

cust_id_order_label = ttk.Label(order_tab, text="Customer ID:")
cust_id_order_label.grid(row=1, column=0, padx=10, pady=10)
cust_id_order_entry = ttk.Entry(order_tab)
cust_id_order_entry.grid(row=1, column=1, padx=10, pady=10)

ticket_no_label = ttk.Label(order_tab, text="Ticket No:")
ticket_no_label.grid(row=2, column=0, padx=10, pady=10)
ticket_no_entry = ttk.Entry(order_tab)
ticket_no_entry.grid(row=2, column=1, padx=10, pady=10)

order_date_label = ttk.Label(order_tab, text="Order Date (YYYY-MM-DD):")
order_date_label.grid(row=3, column=0, padx=10, pady=10)
order_date_entry = ttk.Entry(order_tab)
order_date_entry.grid(row=3, column=1, padx=10, pady=10)

order_time_label = ttk.Label(order_tab, text="Order Time (HH:MM):")
order_time_label.grid(row=4, column=0, padx=10, pady=10)
order_time_entry = ttk.Entry(order_tab)
order_time_entry.grid(row=4, column=1, padx=10, pady=10)

order_class_label = ttk.Label(order_tab, text="Order Class:")
order_class_label.grid(row=5, column=0, padx=10, pady=10)
order_class_entry = ttk.Entry(order_tab)
order_class_entry.grid(row=5, column=1, padx=10, pady=10)

insert_order_button = ttk.Button(order_tab, text="Insert Order", command=insert_order)
insert_order_button.grid(row=6, column=0, columnspan=2, pady=10)

order_columns = ("order_no", "customer_id", "order_class", "order_date", "order_time", "ticket_no")
order_tree = create_treeview(order_tab, order_columns)
fetch_data("SELECT * FROM orders", order_tree)

food_tab = ttk.Frame(notebook)
notebook.add(food_tab, text="Food Items")

food_id_label = ttk.Label(food_tab, text="Food ID:")
food_id_label.grid(row=0, column=0, padx=10, pady=10)
food_id_entry = ttk.Entry(food_tab)
food_id_entry.grid(row=0, column=1, padx=10, pady=10)

food_name_label = ttk.Label(food_tab, text="Food Name:")
food_name_label.grid(row=1, column=0, padx=10, pady=10)
food_name_entry = ttk.Entry(food_tab)
food_name_entry.grid(row=1, column=1, padx=10, pady=10)

price_label = ttk.Label(food_tab, text="Price:")
price_label.grid(row=2, column=0, padx=10, pady=10)
price_entry = ttk.Entry(food_tab)
price_entry.grid(row=2, column=1, padx=10, pady=10)

category_label = ttk.Label(food_tab, text="Category:")
category_label.grid(row=3, column=0, padx=10, pady=10)
category_entry = ttk.Entry(food_tab)
category_entry.grid(row=3, column=1, padx=10, pady=10)

insert_food_button = ttk.Button(food_tab, text="Insert Food Item", command=insert_food_item)
insert_food_button.grid(row=4, column=0, columnspan=2, pady=10)

food_columns = ("food_id", "category", "food_name", "price")
food_tree = create_treeview(food_tab, food_columns)
fetch_data("SELECT * FROM food_items", food_tree)

payment_tab = ttk.Frame(notebook)
notebook.add(payment_tab, text="Payments")

payment_id_label = ttk.Label(payment_tab, text="Payment ID:")
payment_id_label.grid(row=0, column=0, padx=10, pady=10)
payment_id_entry = ttk.Entry(payment_tab)
payment_id_entry.grid(row=0, column=1, padx=10, pady=10)

payment_cust_id_label = ttk.Label(payment_tab, text="Customer ID:")
payment_cust_id_label.grid(row=1, column=0, padx=10, pady=10)
payment_cust_id_entry = ttk.Entry(payment_tab)
payment_cust_id_entry.grid(row=1, column=1, padx=10, pady=10)

payment_amount_label = ttk.Label(payment_tab, text="Amount:")
payment_amount_label.grid(row=2, column=0, padx=10, pady=10)
payment_amount_entry = ttk.Entry(payment_tab)
payment_amount_entry.grid(row=2, column=1, padx=10, pady=10)

payment_date_label = ttk.Label(payment_tab, text="Payment Date (YYYY-MM-DD):")
payment_date_label.grid(row=3, column=0, padx=10, pady=10)
payment_date_entry = ttk.Entry(payment_tab)
payment_date_entry.grid(row=3, column=1, padx=10, pady=10)

payment_cash_paid_label = ttk.Label(payment_tab, text="Cash Paid:")
payment_cash_paid_label.grid(row=4, column=0, padx=10, pady=10)
payment_cash_paid_entry = ttk.Entry(payment_tab)
payment_cash_paid_entry.grid(row=4, column=1, padx=10, pady=10)

insert_payment_button = ttk.Button(payment_tab, text="Insert Payment", command=insert_payment)
insert_payment_button.grid(row=5, column=0, columnspan=2, pady=10)

payment_columns = ("payment_id", "amount", "cash_paid", "customer_id", "payment_date")
payment_tree = create_treeview(payment_tab, payment_columns)
fetch_data("SELECT * FROM payments", payment_tree)

def clear_customer_fields():
    cust_id_entry.delete(0, tk.END)
    cust_name_entry.delete(0, tk.END)
    cust_email_entry.delete(0, tk.END)
    cust_contact_entry.delete(0, tk.END)


def clear_order_fields():
    order_no_entry.delete(0, tk.END)
    cust_id_order_entry.delete(0, tk.END)
    ticket_no_entry.delete(0, tk.END)
    order_date_entry.delete(0, tk.END)
    order_time_entry.delete(0, tk.END)
    order_class_entry.delete(0, tk.END)


def clear_food_fields():
    food_id_entry.delete(0, tk.END)
    food_name_entry.delete(0, tk.END)
    price_entry.delete(0, tk.END)
    category_entry.delete(0, tk.END)


def clear_payment_fields():
    payment_id_entry.delete(0, tk.END)
    payment_cust_id_entry.delete(0, tk.END)
    payment_amount_entry.delete(0, tk.END)
    payment_date_entry.delete(0, tk.END)
    payment_cash_paid_entry.delete(0, tk.END)
    
update_customer_button = ttk.Button(customer_tab, text="Update Customer", command=update_customer)
update_customer_button.grid(row=4, column=1, padx=10, pady=10)

delete_customer_button = ttk.Button(customer_tab, text="Delete Customer", command=delete_customer)
delete_customer_button.grid(row=4, column=2, padx=10, pady=10)

update_order_button = ttk.Button(order_tab, text="Update Order", command=update_order)
update_order_button.grid(row=6, column=1, padx=10, pady=10)

delete_order_button = ttk.Button(order_tab, text="Delete Order", command=delete_order)
delete_order_button.grid(row=6, column=2, padx=10, pady=10)

update_food_button = ttk.Button(food_tab, text="Update Food Item", command=update_food_item)
update_food_button.grid(row=4, column=1, padx=10, pady=10)

delete_food_button = ttk.Button(food_tab, text="Delete Food Item", command=delete_food_item)
delete_food_button.grid(row=4, column=2, padx=10, pady=10)

update_payment_button = ttk.Button(payment_tab, text="Update Payment", command=update_payment)
update_payment_button.grid(row=5, column=1, padx=10, pady=10)

delete_payment_button = ttk.Button(payment_tab, text="Delete Payment", command=delete_payment)
delete_payment_button.grid(row=3, column=2, padx=10, pady=10)

root.mainloop()
