from pymongo import MongoClient
import tkinter as tk
from tkinter import ttk, messagebox

# MongoDB connection setup
client = MongoClient("mongodb://localhost:27017/")
db = client['project']
customers_collection = db['Customers']
orders_collection = db['Orders']
food_items_collection = db['Food_Items']
payments_collection = db['Payments']

def fetch_data(collection, treeview):
    try:
        rows = list(collection.find({}, {"_id": 0}))
        treeview.delete(*treeview.get_children())
        for row in rows:
            row_values = [str(row.get(key, '')) for key in row.keys()]
            treeview.insert("", tk.END, values=row_values)
    except Exception as error:
        messagebox.showerror("Error", str(error))

def create_treeview(parent_frame, columns):
    tree_frame = ttk.Frame(parent_frame)
    tree_frame.grid(row=10,pady=70 ,column=0, columnspan=2, sticky="nsew")

    tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=10)
    tree.grid(row=0, column=0, sticky="nsew")

    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, anchor="center", stretch=True)

    tree_frame.grid_rowconfigure(0, weight=1)
    tree_frame.grid_columnconfigure(0, weight=1)

    total_width = 1000  
    for col in columns:
        tree.column(col, width=total_width // len(columns), anchor="center")

    return tree


# Functions for inserting data
def insert_customer():
    try:
        customer_id = cust_id_entry.get()
        name = cust_name_entry.get()
        email = cust_email_entry.get()
        contact = cust_contact_entry.get()
        
        if not customer_id or not name or not email or not contact:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        customers_collection.insert_one({
            "Customer_id": customer_id,
            "Customer_Name": name,
            "Customer_Email": email,
            "Customer_Contact_No": contact
        })
        messagebox.showinfo("Success", "Customer inserted successfully!")
        fetch_data(customers_collection, customer_tree)
        clear_customer_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

    try:
        selected_item = customer_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a customer to update!")
            return

        customer_id = cust_id_entry.get()
        name = cust_name_entry.get()
        email = cust_email_entry.get()
        contact = cust_contact_entry.get()

        if not customer_id or not name or not email or not contact:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        # Find the selected item in the database and update it
        customers_collection.update_one(
            {"Customer_id": customer_id},
            {"$set": {"Customer_Name": name, "Customer_Email": email, "Customer_Contact_No": contact}}
        )
        messagebox.showinfo("Success", "Customer updated successfully!")
        fetch_data(customers_collection, customer_tree)
        clear_customer_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))
def insert_order():
    try:
        order_no = order_no_entry.get()
        customer_id = cust_id_order_entry.get()
        ticket_no = ticket_no_entry.get()
        order_date = order_date_entry.get()
        order_time = order_time_entry.get()
        order_class = order_class_entry.get()

        if not order_no or not customer_id or not ticket_no or not order_date or not order_time or not order_class:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        orders_collection.insert_one({
            "Order_No": order_no,
            "Customer_id": customer_id,
            "Ticket_No": ticket_no,
            "Order_Date": order_date,
            "Order_Time": order_time,
            "Order_Class": order_class
        })
        messagebox.showinfo("Success", "Order inserted successfully!")
        fetch_data(orders_collection, order_tree)
        clear_order_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def insert_food_item():
    try:
        food_id = food_id_entry.get()
        food_name = food_name_entry.get()
        price = price_entry.get()
        category = category_entry.get()

        if not food_id or not food_name or not price or not category:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        food_items_collection.insert_one({
            "Food_ID": food_id,
            "Food_Name": food_name,
            "Price": float(price),
            "Category": category
        })
        messagebox.showinfo("Success", "Food item inserted successfully!")
        fetch_data(food_items_collection, food_tree)
        clear_food_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def insert_payment():
    try:
        payment_id = payment_id_entry.get()
        customer_id = payment_cust_id_entry.get()
        amount = payment_amount_entry.get()
        payment_date = payment_date_entry.get()
        cash_paid = payment_cash_paid_entry.get()

        if not payment_id or not customer_id or not amount or not payment_date or not cash_paid:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        payments_collection.insert_one({
            "Payment_ID": payment_id,
            "Customer_id": customer_id,
            "Amount": float(amount),
            "Payment_Date": payment_date,
            "Cash_Paid": float(cash_paid)
        })
        messagebox.showinfo("Success", "Payment inserted successfully!")
        fetch_data(payments_collection, payment_tree)
        clear_payment_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Clear input fields
def clear_customer_fields():
    cust_id_entry.delete(0, tk.END)
    cust_name_entry.delete(0, tk.END)
    cust_email_entry.delete(0, tk.END)
    cust_contact_entry.delete(0, tk.END)

def clear_order_fields():
    order_no_entry.delete(0, tk.END)
    cust_id_order_entry.delete(0, tk.END)
    ticket_no_entry.delete(0, tk.END)
    order_date_entry.delete(0, tk.END)
    order_time_entry.delete(0, tk.END)
    order_class_entry.delete(0, tk.END)

def clear_food_fields():
    food_id_entry.delete(0, tk.END)
    food_name_entry.delete(0, tk.END)
    price_entry.delete(0, tk.END)
    category_entry.delete(0, tk.END)

def clear_payment_fields():
    payment_id_entry.delete(0, tk.END)
    payment_cust_id_entry.delete(0, tk.END)
    payment_amount_entry.delete(0, tk.END)
    payment_date_entry.delete(0, tk.END)
    payment_cash_paid_entry.delete(0, tk.END)
# Update and Delete Functions
def update_customer():
    try:
        selected_item = customer_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a customer to update!")
            return

        customer_id = cust_id_entry.get()
        name = cust_name_entry.get()
        email = cust_email_entry.get()
        contact = cust_contact_entry.get()

        if not customer_id or not name or not email or not contact:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        # Find the selected item in the database and update it
        customers_collection.update_one(
            {"Customer_id": customer_id},
            {"$set": {"Customer_Name": name, "Customer_Email": email, "Customer_Contact_No": contact}}
        )
        messagebox.showinfo("Success", "Customer updated successfully!")
        fetch_data(customers_collection, customer_tree)
        clear_customer_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def delete_customer():
    try:
        selected_item = customer_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a customer to delete!")
            return

        customer_id = customer_tree.item(selected_item)["values"][0]  # Get the ID of the selected customer

        # Delete the customer from the database
        customers_collection.delete_one({"Customer_id": customer_id})
        messagebox.showinfo("Success", "Customer deleted successfully!")
        fetch_data(customers_collection, customer_tree)
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Similar functions for Orders
def update_order():
    try:
        selected_item = order_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select an order to update!")
            return

        order_no = order_no_entry.get()
        customer_id = cust_id_order_entry.get()
        ticket_no = ticket_no_entry.get()
        order_date = order_date_entry.get()
        order_time = order_time_entry.get()
        order_class = order_class_entry.get()

        if not order_no or not customer_id or not ticket_no or not order_date or not order_time or not order_class:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        orders_collection.update_one(
            {"Order_No": order_no},
            {"$set": {"Customer_id": customer_id, "Ticket_No": ticket_no,
                      "Order_Date": order_date, "Order_Time": order_time,
                      "Order_Class": order_class}}
        )
        messagebox.showinfo("Success", "Order updated successfully!")
        fetch_data(orders_collection, order_tree)
        clear_order_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def delete_order():
    try:
        selected_item = order_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select an order to delete!")
            return

        order_no = order_tree.item(selected_item)["values"][0]
        orders_collection.delete_one({"Order_No": order_no})
        messagebox.showinfo("Success", "Order deleted successfully!")
        fetch_data(orders_collection, order_tree)
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Repeat for Food Items and Payments with similar structure
def update_food_item():
    try:
        selected_item = food_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a food item to update!")
            return

        food_id = food_id_entry.get()
        food_name = food_name_entry.get()
        price = price_entry.get()
        category = category_entry.get()

        if not food_id or not food_name or not price or not category:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        food_items_collection.update_one(
            {"Food_ID": food_id},
            {"$set": {"Food_Name": food_name, "Price": float(price), "Category": category}}
        )
        messagebox.showinfo("Success", "Food item updated successfully!")
        fetch_data(food_items_collection, food_tree)
        clear_food_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def delete_food_item():
    try:
        selected_item = food_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a food item to delete!")
            return

        food_id = food_tree.item(selected_item)["values"][0]
        food_items_collection.delete_one({"Food_ID": food_id})
        messagebox.showinfo("Success", "Food item deleted successfully!")
        fetch_data(food_items_collection, food_tree)
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Add similar update and delete functions for Payments
def update_payment():
    try:
        selected_item = payment_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a payment to update!")
            return

        payment_id = payment_id_entry.get()
        customer_id = payment_cust_id_entry.get()
        amount = payment_amount_entry.get()
        payment_date = payment_date_entry.get()
        cash_paid = payment_cash_paid_entry.get()

        if not payment_id or not customer_id or not amount or not payment_date or not cash_paid:
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        payments_collection.update_one(
            {"Payment_ID": payment_id},
            {"$set": {"Customer_id": customer_id, "Amount": float(amount),
                      "Payment_Date": payment_date, "Cash_Paid": float(cash_paid)}}
        )
        messagebox.showinfo("Success", "Payment updated successfully!")
        fetch_data(payments_collection, payment_tree)
        clear_payment_fields()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def delete_payment():
    try:
        selected_item = payment_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a payment to delete!")
            return

        payment_id = payment_tree.item(selected_item)["values"][0]
        payments_collection.delete_one({"Payment_ID": payment_id})
        messagebox.showinfo("Success", "Payment deleted successfully!")
        fetch_data(payments_collection, payment_tree)
    except Exception as e:
        messagebox.showerror("Error", str(e))
# Tkinter window setup
root = tk.Tk()
root.title("Database Management System")
root.geometry("1000x700")
root.configure(bg='#eaeaea')
root.iconphoto(False, tk.PhotoImage(file="./database-management.png"))

# Create Notebook for tabs
notebook = ttk.Notebook(root)
notebook.pack(pady=10, expand=True, fill="both")

### Customers Tab ###
customer_frame = ttk.Frame(notebook)
notebook.add(customer_frame, text="Customers")

# Input fields for Customers
tk.Label(customer_frame, text="Customer ID:", bg='#eaeaea', font=('Arial', 12)).grid(row=0, column=0, padx=5, pady=5)
cust_id_entry = tk.Entry(customer_frame, font=('Arial', 12))
cust_id_entry.grid(row=0, column=1, padx=5, pady=5)

tk.Label(customer_frame, text="Name:", bg='#eaeaea', font=('Arial', 12)).grid(row=1, column=0, padx=5, pady=5)
cust_name_entry = tk.Entry(customer_frame, font=('Arial', 12))
cust_name_entry.grid(row=1, column=1, padx=5, pady=5)

tk.Label(customer_frame, text="Email:", bg='#eaeaea', font=('Arial', 12)).grid(row=2, column=0, padx=5, pady=5)
cust_email_entry = tk.Entry(customer_frame, font=('Arial', 12))
cust_email_entry.grid(row=2, column=1, padx=5, pady=5)

tk.Label(customer_frame, text="Contact:", bg='#eaeaea', font=('Arial', 12)).grid(row=3, column=0, padx=5, pady=5)
cust_contact_entry = tk.Entry(customer_frame, font=('Arial', 12))
cust_contact_entry.grid(row=3, column=1, padx=5, pady=5)

# Buttons for Customers
tk.Button(customer_frame, text="Insert", command=insert_customer, bg='#5cb85c', fg='white', font=('Arial', 12)).grid(row=4, column=0, padx=10, pady=10)  # زر إدخال
tk.Button(customer_frame, text="Show", command=lambda: fetch_data(customers_collection, customer_tree), bg='#5bc0de', fg='white', font=('Arial', 12)).grid(row=4, column=1, padx=10, pady=10)  # زر عرض البيانات
tk.Button(customer_frame, text="Update", command=update_customer, bg='#f0ad4e', fg='black', font=('Arial', 12)).grid(row=5, column=0, padx=10, pady=10)  # زر تحديث
tk.Button(customer_frame, text="Delete", command=delete_customer, bg='#d9534f', fg='white', font=('Arial', 12)).grid(row=5, column=1, padx=10, pady=10)  # زر حذف

customer_tree = create_treeview(customer_frame, ("Customer ID", "Name", "Email", "Contact"))

### Orders Tab ###
order_frame = ttk.Frame(notebook)
notebook.add(order_frame, text="Orders")
# Input fields for Orders
tk.Label(order_frame, text="Order No:", bg='#eaeaea', font=('Arial', 12)).grid(row=0, column=0, padx=5, pady=5)
order_no_entry = tk.Entry(order_frame, font=('Arial', 12))
order_no_entry.grid(row=0, column=1, padx=5, pady=5)

tk.Label(order_frame, text="Customer ID:", bg='#eaeaea', font=('Arial', 12)).grid(row=1, column=0, padx=5, pady=5)
cust_id_order_entry = tk.Entry(order_frame, font=('Arial', 12))
cust_id_order_entry.grid(row=1, column=1, padx=5, pady=5)

tk.Label(order_frame, text="Ticket No:", bg='#eaeaea', font=('Arial', 12)).grid(row=2, column=0, padx=5, pady=5)
ticket_no_entry = tk.Entry(order_frame, font=('Arial', 12))
ticket_no_entry.grid(row=2, column=1, padx=5, pady=5)

tk.Label(order_frame, text="Order Date:", bg='#eaeaea', font=('Arial', 12)).grid(row=3, column=0, padx=5, pady=5)
order_date_entry = tk.Entry(order_frame, font=('Arial', 12))
order_date_entry.grid(row=3, column=1, padx=5, pady=5)

tk.Label(order_frame, text="Order Time:", bg='#eaeaea', font=('Arial', 12)).grid(row=4, column=0, padx=5, pady=5)
order_time_entry = tk.Entry(order_frame, font=('Arial', 12))
order_time_entry.grid(row=4, column=1, padx=5, pady=5)

tk.Label(order_frame, text="Order Class:", bg='#eaeaea', font=('Arial', 12)).grid(row=5, column=0, padx=5, pady=5)
order_class_entry = tk.Entry(order_frame, font=('Arial', 12))
order_class_entry.grid(row=5, column=1, padx=5, pady=5)

tk.Button(order_frame, text="Insert", command=insert_order, bg='#5cb85c', fg='white', font=('Arial', 12)).grid(row=6, column=0, padx=10, pady=25)  # رفع الأزرار قليلاً
tk.Button(order_frame, text="Show", command=lambda: fetch_data(orders_collection, order_tree), bg='#5bc0de', fg='white', font=('Arial', 12)).grid(row=6, column=1, padx=10, pady=20)  # رفع الأزرار قليلاً
tk.Button(order_frame, text="Update", command=update_order, bg='#f0ad4e', fg='black', font=('Arial', 12)).grid(row=7, column=0, padx=10, pady=25)  # رفع الأزرار قليلاً
tk.Button(order_frame, text="Delete", command=delete_order, bg='#d9534f', fg='white', font=('Arial', 12)).grid(row=7, column=1, padx=10, pady=25)  # رفع الأزرار قليلاً

order_tree = create_treeview(order_frame, ("Order No", "Customer ID", "Ticket No", "Order Date", "Order Time", "Order Class"))

### Food Items Tab ###
food_frame = ttk.Frame(notebook)
notebook.add(food_frame, text="Food Items")

# Input fields for Food Items
tk.Label(food_frame, text="Food ID:", bg='#eaeaea', font=('Arial', 12)).grid(row=0, column=0, padx=5, pady=5)
food_id_entry = tk.Entry(food_frame, font=('Arial', 12))
food_id_entry.grid(row=0, column=1, padx=5, pady=5)

tk.Label(food_frame, text="Food Name:", bg='#eaeaea', font=('Arial', 12)).grid(row=1, column=0, padx=5, pady=5)
food_name_entry = tk.Entry(food_frame, font=('Arial', 12))
food_name_entry.grid(row=1, column=1, padx=5, pady=5)

tk.Label(food_frame, text="Price:", bg='#eaeaea', font=('Arial', 12)).grid(row=2, column=0, padx=5, pady=5)
price_entry = tk.Entry(food_frame, font=('Arial', 12))
price_entry.grid(row=2, column=1, padx=5, pady=5)

tk.Label(food_frame, text="Category:", bg='#eaeaea', font=('Arial', 12)).grid(row=3, column=0, padx=5, pady=5)
category_entry = tk.Entry(food_frame, font=('Arial', 12))
category_entry.grid(row=3, column=1, padx=5, pady=5)

# Buttons for Food Items
tk.Button(food_frame, text="Insert", command=insert_food_item, bg='#5cb85c', fg='white', font=('Arial', 12)).grid(row=4, column=0, padx=10, pady=10)  # زر إدخال
tk.Button(food_frame, text="Show", command=lambda: fetch_data(food_items_collection, food_tree), bg='#5bc0de', fg='white', font=('Arial', 12)).grid(row=4, column=1, padx=10, pady=10)  # زر عرض البيانات
tk.Button(food_frame, text="Update", command=update_food_item, bg='#f0ad4e', fg='black', font=('Arial', 12)).grid(row=5, column=0, padx=10, pady=10)  # زر تحديث
tk.Button(food_frame, text="Delete", command=delete_food_item, bg='#d9534f', fg='white', font=('Arial', 12)).grid(row=5, column=1, padx=10, pady=10)  # زر حذف

food_tree = create_treeview(food_frame, ("Food ID", "Food Name", "Price", "Category"))

### Payments Tab ###
payment_frame = ttk.Frame(notebook)
notebook.add(payment_frame, text="Payments")

# Input fields for Payments
tk.Label(payment_frame, text="Payment ID:", bg='#eaeaea', font=('Arial', 12)).grid(row=0, column=0, padx=5, pady=5)
payment_id_entry = tk.Entry(payment_frame, font=('Arial', 12))
payment_id_entry.grid(row=0, column=1, padx=5, pady=5)

tk.Label(payment_frame, text="Customer ID:", bg='#eaeaea', font=('Arial', 12)).grid(row=1, column=0, padx=5, pady=5)
payment_cust_id_entry = tk.Entry(payment_frame, font=('Arial', 12))
payment_cust_id_entry.grid(row=1, column=1, padx=5, pady=5)

tk.Label(payment_frame, text="Amount:", bg='#eaeaea', font=('Arial', 12)).grid(row=2, column=0, padx=5, pady=5)
payment_amount_entry = tk.Entry(payment_frame, font=('Arial', 12))
payment_amount_entry.grid(row=2, column=1, padx=5, pady=5)

tk.Label(payment_frame, text="Date:", bg='#eaeaea', font=('Arial', 12)).grid(row=3, column=0, padx=5, pady=5)
payment_date_entry = tk.Entry(payment_frame, font=('Arial', 12))
payment_date_entry.grid(row=3, column=1, padx=5, pady=5)

tk.Label(payment_frame, text="Cash Paid:", bg='#eaeaea', font=('Arial', 12)).grid(row=4, column=0, padx=5, pady=5)
payment_cash_paid_entry = tk.Entry(payment_frame, font=('Arial', 12))
payment_cash_paid_entry.grid(row=4, column=1, padx=5, pady=5)

# Buttons for Payments
tk.Button(payment_frame, text="Insert", command=insert_payment, bg='#5cb85c', fg='white', font=('Arial', 12)).grid(row=5, column=0, padx=10, pady=10)  # زر إدخال
tk.Button(payment_frame, text="Show", command=lambda: fetch_data(payments_collection, payment_tree), bg='#5bc0de', fg='white', font=('Arial', 12)).grid(row=5, column=1, padx=10, pady=10)  # زر عرض البيانات
tk.Button(payment_frame, text="Update", command=update_payment, bg='#f0ad4e', fg='black', font=('Arial', 12)).grid(row=6, column=0, padx=10, pady=10)  # زر تحديث
tk.Button(payment_frame, text="Delete", command=delete_payment, bg='#d9534f', fg='white', font=('Arial', 12)).grid(row=6, column=1, padx=10, pady=10)  # زر حذف

payment_tree = create_treeview(payment_frame, ("Payment ID", "Customer ID", "Amount", "Payment Date", "Cash Paid"))


root.mainloop()